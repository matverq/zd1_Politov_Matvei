﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr1_2_Politov_Matvei
{
    class Shop
    {
        private Dictionary<Product, int> products;
        public decimal profit = 0;
        //Конструктор класса
        public Shop()
        {
            products = new Dictionary<Product, int>();
        }
        //Добавление готовго товара на склад
        public void AddProduct(Product product, int count)
        {
            if (products.ContainsKey(product))
            {
                products[product] += count;
            }
            else
            {
                products.Add(product, count);
            }
        }
        //Выдает список товаров
        public Dictionary<Product, int>GetProducts()
        {
            return products;
        }
        //Берет текст о каждом товаре и его количестве для вывода на экран
        public List<string> WriteAllProducts()
        {
            List<string> result = new List<string>();
            foreach (var product in products)
            {
                result.Add(product.Key.GetInfo() + "Количество: " + product.Value);
            }
            return result;
        }
        //Создание товара
        public void CreateProduct(string name, decimal price, int count)
        {
            products.Add(new Product(name, price), count);
        }
        //Списание товара  при покупке и получение прибыли
        public bool Sell(Product product, int count)
        {
            if (products.ContainsKey(product))
            {
                if (products[product] < count)
                {
                    return false;
                }
                else
                {
                    products[product] -= count;
                    profit += product.Price * count;
                    return true;
                }
            }
            return false;
        }
        //Прибыль до вычета налогов
        public decimal GetProfit()
        {
            return profit;
        }
        //прибыль после вычета налогов
        public decimal GetProfit(decimal taxPercent)
        {
            return profit * (1 - (taxPercent / 100));
        }
        //Поиск товара на складе по названии
        public Product FindByName(string name)
        {
            foreach(var product in GetProducts().Keys) 
            {
                if(product.Name == name)
                {
                    return product;
                }
            }
            return null;
        }

    }
}
