﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr1_2_Politov_Matvei
{
    class Product
    {
        public decimal Price { get; set; }
        public string Name { get; set; }
        //Конструкор для нового товара
        public Product(string Name, decimal Price)
        {
            this.Name = Name;
            this.Price = Price;
        }
        //Вывод информации
        public string GetInfo()
        {
            return $"Наименование: {Name}; Цена: {Price}";
        }
    }
}
