﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr1_2_Politov_Matvei
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Shop pyaterochka;
        //Конструктор главного окна
        public MainWindow()
        {
            InitializeComponent();
            pyaterochka = new Shop();
            //использование методов из класса для изначального создания данных
            pyaterochka.CreateProduct("Кола", 85, 200);
            pyaterochka.CreateProduct("Сок \"Добрый\"", 100, 50);
            UpdateWarehouseUI();
        }
        //обновление списка товаров и строки прибыли
        private void UpdateWarehouseUI()
        {
            LstProducts.Items.Clear();
            List<string> allProductsLines = pyaterochka.WriteAllProducts();
            foreach (string line in allProductsLines)
            {
                LstProducts.Items.Add(line);
            }
            TxtProfit.Text = $"Прибыль(без налогов): {pyaterochka.GetProfit()} руб.\n Прибыль(с налогами): {pyaterochka.GetProfit(13)} руб.";
        }
        //Переключение на панель склада
        private void Menu_Warehouse_Click(object sender, RoutedEventArgs e)
        {
            UpdateWarehouseUI();
            PanelWarehouse.Visibility = Visibility.Visible;
            PanelAdd.Visibility = Visibility.Collapsed;
            PanelSell.Visibility = Visibility.Collapsed;
        }
        //Выход из программы
        private void Menu_Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        //открытие панели добавления товара
        private void Menu_Add_Click(object sender, RoutedEventArgs e)
        {
            PanelWarehouse.Visibility = Visibility.Collapsed;
            PanelAdd.Visibility = Visibility.Visible;
            PanelSell.Visibility = Visibility.Collapsed;
        }
        //открытие панели продажи
        private void Menu_Sell_Click(object sender, RoutedEventArgs e)
        {
            PanelWarehouse.Visibility = Visibility.Collapsed;
            PanelAdd.Visibility = Visibility.Collapsed;
            PanelSell.Visibility = Visibility.Visible;
        }
        //Создание нового товара
        private void CreateProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = TxtNewName.Text.Trim();
                decimal price = decimal.Parse(TxtNewPrice.Text);
                int count = int.Parse(TxtNewCount.Text);
                if (string.IsNullOrEmpty(name))
                {
                    MessageBox.Show("Введите название товара!");
                    return;
                }
                Product newProduct = new Product(name, price);
                pyaterochka.AddProduct(newProduct, count);
                TxtNewName.Clear();
                TxtNewPrice.Clear();
                TxtNewCount.Clear();
                MessageBox.Show("Товар успешно добавлен!");
                Menu_Warehouse_Click(null, null);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка ввода данных: {ex.Message}");
            }
        }
        //Продажа товара за счет его поиска по названию(FiendByName) и списывает в зависимости от введенной суммы
        private void SellProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string searchName = TxtSellName.Text.Trim();
                int countToBuy = int.Parse(TxtSellAmount.Text);
                Product toSell = pyaterochka.FindByName(searchName);
                if (toSell == null)
                {
                    MessageBox.Show("Товар не найден!");
                    return;
                }
                bool success = pyaterochka.Sell(toSell, countToBuy);
                if (success)
                {
                    MessageBox.Show("Товар успешно продан!");
                    TxtSellName.Clear();
                    TxtSellAmount.Text = "1";
                    Menu_Warehouse_Click(null, null);
                }
                else
                {
                    MessageBox.Show("Недостаточно количества товара на складе!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при оформлении продажи: {ex.Message}");
            }
        }
    }
}
