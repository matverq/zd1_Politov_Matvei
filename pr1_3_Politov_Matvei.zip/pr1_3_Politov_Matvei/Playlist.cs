﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr1_3_Politov_Matvei
{
    class Playlist
    {
        private List<Song> list;
        private int currentIndex;
        
        public Playlist()
        {
            list = new List<Song>();
            currentIndex = 0;
        }
        //Вывод играющей песни
        public Song CurrentSong()
        {
            if (list.Count > 0) 
            {
                if (currentIndex >= 0 && currentIndex < list.Count)
                {
                    return list[currentIndex];
                }
                else
                {
                    throw new IndexOutOfRangeException("Невозможно получить текущую аудиозапись из за неверного индекса");
                }
            }
            else  throw new IndexOutOfRangeException("Невозможно получить текущую аудиозапись для пустого плейлиста!"); 
        }
        public int Count
        {
            get { return list.Count; }
        }
        //Добавление новой песни(1)
        public void Add(Song song)
        {
            for(int i=0; i < list.Count;i++)
            {
                if (list[i].Author==song.Author && list[i].Title==song.Title&& list[i].Filename==song.Filename)
                {
                    return;
                }
            }
            list.Add(song);
        }
        //Добавление новой песни(2)
        public void Add(string author, string title, string fname)
        {
            Song newSong;
            newSong.Author = author;
            newSong.Title = title;
            newSong.Filename = fname;
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].Author == newSong.Author && list[i].Title == newSong.Title && list[i].Filename == newSong.Filename)
                {
                    return;
                }
            }
            list.Add(newSong);
        }
        //Переход к следующей песне
        public void Next()
        {
            if(list.Count==0)  return;

            if(currentIndex < list.Count-1)
            {
                currentIndex = currentIndex + 1;
            }
        }
        //Переход к прошлой песне
        public void Back()
        {
            if (list.Count == 0) return;

            if (currentIndex > 0)
            {
                currentIndex = currentIndex -1;
            }
        }
        //Переход к песне по индексу
        public void MoveTo(int index)
        {
            if (index >= 0 && index < list.Count)
            {
                currentIndex = index;
            }
        }
        //Переход в начало плейлиста
        public void First()
        {
            if(list.Count>0)
            {
                currentIndex = 0;
            }
        }
        //Удаление по индексу(порядковый номер)
        public void Remove(int index)
        {
            if(index >= 0 && index < list.Count)
            {
                list.RemoveAt(index);
                if (currentIndex >= list.Count && list.Count >0)
                {
                    currentIndex = list.Count - 1;
                }
            }
        }
        //Удаление по объекту(совпадение всех полей) 
        public void Remove(Song song)
        {
            for(int i=0; i< list.Count;i++)
            {
                if(list[i].Author==song.Author && list[i].Title==song.Title && list[i].Filename==song.Filename)
                {
                    list.RemoveAt(i);
                    if (currentIndex >=list.Count && list.Count>0)
                    {
                        currentIndex = list.Count - 1;
                    }
                    break;
                }
            }
        }
        //Очистка плейлиста
        public void Clear()
        {
            list.Clear();
            currentIndex = 0;
        }
        //отдает список в listbox
        public List<Song> GetAllSongs()
        {
            return list;
        }
    }
}