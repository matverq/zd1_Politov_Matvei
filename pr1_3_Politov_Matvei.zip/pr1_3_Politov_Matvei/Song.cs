﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr1_3_Politov_Matvei
{
    public struct Song
    {
        public string Author;
        public string Title;
        public string Filename;
    }
}
