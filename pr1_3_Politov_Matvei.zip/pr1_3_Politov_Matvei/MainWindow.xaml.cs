﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace pr1_3_Politov_Matvei
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Playlist myplaylist = new Playlist();
        public MainWindow()
        {
            InitializeComponent();
            Update();
        }
        //Удаление текущего, и вывод нового(измененного) списка
        private void Update()
        {
            List.Items.Clear();
            var alltracks = myplaylist.GetAllSongs();
            for(int i=0;i<alltracks.Count;i++)
            {
                List.Items.Add(alltracks[i].Author + " - " + alltracks[i].Title);
            }
            try
            {
                Song realsong = myplaylist.CurrentSong();
                realTrack.Text = "Играет: " + realsong.Author + " - " + realsong.Title;
            }
            catch(IndexOutOfRangeException)
            {
                realTrack.Text = "Плейлист пуст";
            }
        }
        //Очистка списка
        private void ClearMenu(object sender, RoutedEventArgs e)
        {
            myplaylist.Clear();
            Update();
        }
        //Выход из программы
        private void ExiteMenu(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        //Добавление песни по передаче объекта структоры (1)
        private void Add1_Click(object sender, RoutedEventArgs e)
        {
            if (pAuthor.Text != "" && pName.Text!="" && fName.Text!="")
            {
                Song newtrack;
                newtrack.Author = pAuthor.Text;
                newtrack.Title = pName.Text;
                newtrack.Filename = fName.Text;
                myplaylist.Add(newtrack);
                Update();
            }
            else
            {
                MessageBox.Show("Заполнен не все поля");
            }
        }
        //Добавление песни по передаче трех текстовых полей (2)
        private void Add2_Click(object sender, RoutedEventArgs e)
        {
            if (pAuthor.Text != "" && pName.Text != "" && fName.Text != "")
            {
                myplaylist.Add(pAuthor.Text, pName.Text, fName.Text);
                Update();
            }
            else
            {
                MessageBox.Show("Заполнен не все поля");
            }
        }
        //Возврат на первую позицию в списке
        private void GoFirst_Click(object sender, RoutedEventArgs e)
        {
            myplaylist.First();
            Update();
        }
        //перемещение на одну песню назад
        private void GoBack_Click(object sender, RoutedEventArgs e)
        {
            myplaylist.Back();
            Update();
        }
        //перемещение на одну песню вперед
        private void GoNext_Click(object sender, RoutedEventArgs e)
        {
            myplaylist.Next();
            Update();
        }
        //Удаление песни по индексу (1)
        private void RemoveInd_Click(object sender, RoutedEventArgs e)
        {
            if (myplaylist.Count > 0)
            {
                if (int.TryParse(pInd.Text, out int enterInd))
                {
                    myplaylist.Remove(enterInd);
                    Update();
                }
                else
                {
                    MessageBox.Show("Песни с таким номером не существует");
                }
            }
            else
            {
                MessageBox.Show("Введите корректное число");
            }
        }
        //Удаление выбранной песни (2)
        private void RemoveObj_Click(object sender, RoutedEventArgs e)
        {
            if (myplaylist.Count > 0)
            {
                try
                {
                    Song realsong = myplaylist.CurrentSong();
                    myplaylist.Remove(realsong);
                    Update();
                }
                catch(Exception)
                {

                }
            }
        }
        //Переход к песне по индексу
        private void GoInd_Click(object sender, RoutedEventArgs e)
        {
            if(int.TryParse(pInd.Text, out int enterInd))
            {
                   if(enterInd >=0 && enterInd<myplaylist.Count)
                   {
                      myplaylist.MoveTo(enterInd);
                      Update();
                   }
                else
                {
                    MessageBox.Show("Песни с таким номером не существует");
                }
            }
            else
            {
                MessageBox.Show("Введен некорректный символ");
            }
        }
    }
}